import 'package:flutter/material.dart';

class Home extends StatelessWidget {
  Home({super.key});
  final GlobalKey<FormState> myKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
appBar: AppBar(title: Text('Home'),centerTitle: true,),
      body: Container(

        child: Text('body'),
      ),
    );
  }
}

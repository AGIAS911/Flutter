import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class Register extends StatelessWidget {
  Register({super.key});
  final GlobalKey<FormState> myKey = GlobalKey<FormState>();
  final TextEditingController _nationalIdController = TextEditingController();
  final TextEditingController _birthdayController = TextEditingController();
  final TextEditingController _idCardNumberController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
      child:Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color.fromARGB(255, 25, 49, 85),
              Color.fromARGB(255, 129, 134, 146),
              Color.fromARGB(255, 183, 193, 202),
            ],
          ),
        ),
        child: Form(
          key: myKey,
          child: Column(
            children: [
              SizedBox(height: 80),
              Row(
                children: [
                  SvgPicture.asset(
                    'assets/logo-svg.svg',
                    width: 150,
                    height: 100,
                    color: const Color.fromARGB(255, 0, 0, 0),
                  ),
                  SizedBox(width: 10),
                  Text(
                    "Register",
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 35,
                      fontFamily: 'Roboto',
                    ),
                  ),
                ],
              ),
              SizedBox(height: 50),
              TextFormField(
                controller: _nationalIdController,
                keyboardType: TextInputType.number,
                maxLength: 10,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.badge_outlined),
                  labelText: 'National ID',
                  hintText: 'Enter national id',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'please enter your national id';
                  }
                  var NIDRegExp = RegExp(r'^\d+$');
                  if (!NIDRegExp.hasMatch(value)) {
                    return 'please enter a valid Id';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: _birthdayController,
                keyboardType: TextInputType.datetime,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.calendar_month),
                  labelText: 'Birthday',
                  hintText: 'DD/MM/YYYY',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'please enter your birthday';
                  }
                  var BirthRegExp = RegExp(
                    r'^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$',
                  );
                  if (!BirthRegExp.hasMatch(value)) {
                    return 'please enter a valid birthday format';
                  }
                  return null;
                },
              ),
              SizedBox(height: 12),
              TextFormField(
                controller: _idCardNumberController,
                keyboardType: TextInputType.text,
                maxLength: 8,

                decoration: InputDecoration(
                  prefixIcon: Icon(Icons.confirmation_num_outlined),
                  labelText: 'ID Card Number',
                  hintText: 'Enter ID card number',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),

                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'please enter your card id';
                  }
                  var CIDRegExp = RegExp(r'^[A-Z]{3}[0-9]{5}$');
                  if (!CIDRegExp.hasMatch(value)) {
                    return 'please enter a valid card Id';
                  }
                  return null;
                },
              ),

              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.lock_outline),
                  labelText: 'Password',
                  hintText: 'Enter password',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter password';
                  }
                  if (value.length < 8) {
                    return 'Password must be at least 8 characters';
                  }
                  if (!RegExp(r'[A-Z]').hasMatch(value)) {
                    return 'Password must contain at least one uppercase letter';
                  }
                  if (!RegExp(r'[a-z]').hasMatch(value)) {
                    return 'Password must contain at least one lowercase letter';
                  }
                  if (!RegExp(r'\d').hasMatch(value)) {
                    return 'Password must contain at least one number';
                  }
                  if (!RegExp(r'[@$!%*?&]').hasMatch(value)) {
                    return 'Password must contain at least one special character';
                  }
                  return null; // valid password
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _confirmPasswordController,
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.lock),
                  labelText: 'Confirm Password',
                  hintText: 'Re-enter password',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                ),
                autovalidateMode: AutovalidateMode.onUserInteraction,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'please Re-enter your password';
                  }

                  if (_confirmPasswordController.text !=
                      _passwordController.text) {
                    return 'The passowrd does not matched';
                  }
                  return null;
                },
              ),
              SizedBox(height: 80),
              Container(
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 25, 49, 85),
                ),

                width: 120,
                height: 50,
                child: ElevatedButton(
                  onPressed: () {
                    if (myKey.currentState!.validate()) {
                      Navigator.pushReplacementNamed(context, 'login');
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Please fill all fields correctly'),
                        ),
                      );
                    }
                  },
                  child: Text('Sign up'),
                ),
              ),
              SizedBox(height: 20),

              TextButton(
                onPressed: () {
                  Navigator.pushReplacementNamed(context, 'login');
                },
                child: Text(
                  'Already have an account?',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w500, // medium weight
                    color: const Color.fromARGB(255, 49, 113, 231),
                    letterSpacing: 0.5,
                    decoration: TextDecoration.underline,
                  ),
                ),
              ),
            ],
          ),
        ),
      )
      ),
    );
  }
}

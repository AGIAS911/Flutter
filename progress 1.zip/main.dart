import 'package:flutter/material.dart';
import 'package:my_project/home.dart';
import 'package:my_project/login.dart';
import 'package:my_project/register.dart';

void main() {
  runApp(MainApp());
}

class MainApp extends StatelessWidget {
  MainApp({super.key});


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
     'login':(context)=>Login(),
     'register':(context)=>Register(),
     'home':(context)=>Home(),
      },
      theme: ThemeData(
        primaryColor: Color.fromARGB(255, 5, 58, 55),
        useMaterial3: false,
      ),
      home: Login() 
    );
  }
}

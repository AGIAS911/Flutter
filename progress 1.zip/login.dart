import 'package:flutter/material.dart';

class Login extends StatelessWidget {
  Login({super.key});
  final GlobalKey<FormState> myKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,

          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color.fromARGB(255, 25, 49, 85),
                Color.fromARGB(255, 129, 134, 146),
                Color.fromARGB(255, 183, 193, 202),
              ],
            ),
          ),
          child: Form(
            key: myKey,
            child: Column(
              children: [
                const SizedBox(height: 100),
                Image.asset('assets/log-re.png', height: 150, width: 250),
                const SizedBox(height: 20),
                const Text(
                  'Driver & Vehicle Licensing Department',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
                ),
                const SizedBox(height: 50),

                
                TextFormField(
                  maxLength: 10,
                  keyboardType: TextInputType.number,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'please enter your national id';
                    }
                    var idRegExp = RegExp(r'^\d+$');
                    if (!idRegExp.hasMatch(value)) {
                      return 'please enter a valid Id';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.person),
                    label: const Text('National Id'),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                      borderSide: BorderSide(color: const Color.fromARGB(255, 55, 0, 255))
                    ),
                  ),
                ),

                const SizedBox(height: 15),

              
                TextFormField(
                  maxLength: 15,
                  keyboardType: TextInputType.visiblePassword,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "Please enter password";
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    prefixIcon: const Icon(Icons.password),
                    label: const Text('Password'),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                Padding(
                  padding: const EdgeInsets.only(left: 250),
                  child: TextButton(
                    onPressed: () {},
                    child: const Text(
                      'Forget Password',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        fontSize: 15,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 30),
                SizedBox(
                  height: 30,
                  width: 140,
                  child: ElevatedButton(
                    onPressed: () {
                      myKey.currentState!.validate();
                    },
                    child: const Text('Sign in'),
                  ),
                ),

                const SizedBox(height: 10),
                SizedBox(
                  height: 30,
                  width: 140,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, 'register');
                    },
                    child: const Text('Sign up'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

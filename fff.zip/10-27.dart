import 'package:flutter/material.dart';
// import 'package:flutter_application_8/mywidget.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  List names = ['Ahmad', 'Farah', 'Khaled', 'Layla'];
  List clrs = [Colors.red, Colors.blue, Colors.yellow, Colors.cyan];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Hide debug banner to see more clear

      title: 'Flutter',
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.grey.shade100,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        fontFamily: 'Times New Roman',
        textTheme: TextTheme(
          bodyLarge: TextStyle(
            color: Colors.black87,
            fontSize: 18,
            fontWeight: FontWeight.normal,
          ),
          titleLarge: TextStyle(
            color: Colors.black,
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.grey.shade200,
          foregroundColor: Colors.black,
          elevation: 3,
          centerTitle: true,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
          ),
        ),
      ),

      home: Scaffold(
          appBar: AppBar(
            title: Text('Home Page'),
            leading: Icon(Icons.menu),
            actions: [
              Padding(
                  padding: EdgeInsets.only(right: 10),
                  child: Icon(Icons.person))
            ],
          ),
          body: Container(
              color: Colors.yellow,
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2),
                itemCount: names.length,
                itemBuilder: (context, index) {
                  return Mywidget1(myData: '${names[index]}');
                },
              )
              /*
              ListView.separated(
                separatorBuilder: (context, index) {
                  return Divider();
                },
                itemCount: names.length,
                itemBuilder: (context, index) {
                  return Container(
                      color: clrs[index],
                      height: 50,
                      width: 50,
                      child: Text('The name is ${names[index]}'));
                },
              )*/
              )
          /*
          Container(
              child: GridView(
            gridDelegate:
                SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            children: [
              Container(
                margin: EdgeInsets.all(5),
                width: 50,
                height: 50,
                child: Text('A'),
                color: Colors.blue,
              ),
              /* Divider(
                color: Colors.black,
                height: 5,
                thickness: 1,
              ),*/
              Container(
                width: 50,
                height: 50,
                child: Text('B'),
                color: Colors.yellow,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('C'),
                color: Colors.green,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('D'),
                color: Colors.blue,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('E'),
                color: Colors.yellow,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('F'),
                color: Colors.green,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('G'),
                color: Colors.pink,
              ),
              Container(
                width: 50,
                height: 50,
                child: Text('H'),
                color: Colors.blue,
              ),
            ],
          )
          */
          ),
    );
  }
}

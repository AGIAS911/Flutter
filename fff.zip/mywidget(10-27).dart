import 'package:flutter/material.dart';

class Mywidget1 extends StatelessWidget {
  String myData;
   Mywidget1({super.key, required this.myData});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.red,
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      child: Center(child: Text(myData,style: TextStyle(fontSize: 35),)),
    );
  }
}
